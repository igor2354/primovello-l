// Dynamic Adapt v.1
// HTML data-da="where(uniq class name),when(breakpoint),position(digi),type (min, max)"
// e.x. data-da="item,767,last,max"
// Andrikanych Yevhen 2020
// https://www.youtube.com/c/freelancerlifestyle

class DynamicAdapt {
  // массив объектов
  elementsArray = [];
  daClassname = '_dynamic_adapt_';

  constructor(type) {
    this.type = type;
  }

  init() {
    // массив DOM-элементов
    this.elements = [...document.querySelectorAll('[data-da]')];

    // наполнение elementsArray объктами
    this.elements.forEach((element) => {
      const data = element.dataset.da.trim();
      if (data !== '') {
        const dataArray = data.split(',');

        const oElement = {};
        oElement.element = element;
        oElement.parent = element.parentNode;
        oElement.destination = document.querySelector(`.${dataArray[0].trim()}`);
        oElement.breakpoint = dataArray[1] ? dataArray[1].trim() : '767';
        oElement.place = dataArray[2] ? dataArray[2].trim() : 'last';

        oElement.index = this.indexInParent(
          oElement.parent, oElement.element,
        );

        this.elementsArray.push(oElement);
      }
    });

    this.arraySort(this.elementsArray);

    // массив уникальных медиа-запросов
    this.mediaArray = this.elementsArray
      .map(({ breakpoint }) => `(${this.type}-width: ${breakpoint}px),${breakpoint}`)
      .filter((item, index, self) => self.indexOf(item) === index);

    // навешивание слушателя на медиа-запрос
    // и вызов обработчика при первом запуске
    this.mediaArray.forEach((media) => {
      const mediaSplit = media.split(',');
      const mediaQuerie = window.matchMedia(mediaSplit[0]);
      const mediaBreakpoint = mediaSplit[1];

      // массив объектов с подходящим брейкпоинтом
      const elementsFilter = this.elementsArray.filter(
        ({ breakpoint }) => breakpoint === mediaBreakpoint
      );
      mediaQuerie.addEventListener('change', () => {
        this.mediaHandler(mediaQuerie, elementsFilter);
      });
      this.mediaHandler(mediaQuerie, elementsFilter);
    });
  }

  // Основная функция
  mediaHandler(mediaQuerie, elementsFilter) {
    if (mediaQuerie.matches) {
      elementsFilter.forEach((oElement) => {
        // получение индекса внутри родителя
        oElement.index = this.indexInParent(
          oElement.parent, oElement.element,
        );
        this.moveTo(oElement.place, oElement.element, oElement.destination);
      });
    } else {
      elementsFilter.forEach(({ parent, element, index }) => {
        if (element.classList.contains(this.daClassname)) {
          this.moveBack(parent, element, index);
        }
      });
    }
  }

  // Функция перемещения
  moveTo(place, element, destination) {
    element.classList.add(this.daClassname);
    if (place === 'last' || place >= destination.children.length) {
      destination.append(element);
      return;
    }
    if (place === 'first') {
      destination.prepend(element);
      return;
    }
    destination.children[place].before(element);
  }

  // Функция возврата
  moveBack(parent, element, index) {
    element.classList.remove(this.daClassname);
    if (parent.children[index] !== undefined) {
      parent.children[index].before(element);
    } else {
      parent.append(element);
    }
  }

  // Функция получения индекса внутри родителя
  indexInParent(parent, element) {
    return [...parent.children].indexOf(element);
  }

  // Функция сортировки массива по breakpoint и place 
  // по возрастанию для this.type = min
  // по убыванию для this.type = max
  arraySort(arr) {
    if (this.type === 'min') {
      arr.sort((a, b) => {
        if (a.breakpoint === b.breakpoint) {
          if (a.place === b.place) {
            return 0;
          }
          if (a.place === 'first' || b.place === 'last') {
            return -1;
          }
          if (a.place === 'last' || b.place === 'first') {
            return 1;
          }
          return a.place - b.place;
        }
        return a.breakpoint - b.breakpoint;
      });
    } else {
      arr.sort((a, b) => {
        if (a.breakpoint === b.breakpoint) {
          if (a.place === b.place) {
            return 0;
          }
          if (a.place === 'first' || b.place === 'last') {
            return 1;
          }
          if (a.place === 'last' || b.place === 'first') {
            return -1;
          }
          return b.place - a.place;
        }
        return b.breakpoint - a.breakpoint;
      });
      return;
    }
  }
}

const da = new DynamicAdapt('max');
da.init();